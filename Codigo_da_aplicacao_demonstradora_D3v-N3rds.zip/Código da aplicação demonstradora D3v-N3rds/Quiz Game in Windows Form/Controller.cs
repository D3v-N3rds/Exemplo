﻿
using TinCan;
using System;
using System.Linq;
using System.Text;
using TinCan.LRSResponses;
using System.Windows.Forms;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Quiz_Game_in_Windows_Form
{
    // Classe para armazenar as categorias de trivia obtidas da API.
    public class TriviaCategoryResponse
    {
        [JsonProperty("trivia_categories")]
        public List<Category> Categories { get; set; }
    }

    // Classe para armazenar as perguntas obtidas da API.
    public class QuestionsResponse
    {
        [JsonProperty("results")]
        public List<Question> Questions { get; set; }
    }

    // Classe para armazenar a resposta de token da API.
    public class TokenResponse
    {
        public string Token { get; set; }
    }
    // Classe para representar cada pergunta com a sua resposta correta e incorretas.
    public class Question
    {
        [JsonProperty("question")]
        public string Text { get; set; }

        [JsonProperty("correct_answer")]
        public string CorrectAnswer { get; set; }

        [JsonProperty("incorrect_answers")]
        public List<string> IncorrectAnswers { get; set; }
    }
    // Classe para representar cada categoria de perguntas.
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    
    // Classe Controller que gerencia a lógica do jogo, interações com a API e a View.

    public class Controller
    {
        private Model model;
        private View view;
        private RemoteLRS lrs;
        private System.Windows.Forms.Timer retryTimer = new System.Windows.Forms.Timer();
        
        // Construtor que inicializa o Controller com a View e o Model.
        public Controller(View v, Model m)
        {
            this.view = v;
            this.model = m;
            this.view.Controlador(this);

            retryTimer.Interval = 3000; // 30 segundos
            retryTimer.Tick += TentativaLigacao;

            this.lrs = new RemoteLRS(
                "https://cloud.scorm.com/lrs/G6J5F4XMTM/",  // URL como string
                "G6J5F4XMTM",
                "XLrGjPrcd09K0yZd42XeyIyaT3syCR2nl3vaBtb3"
            );
        }


        // Evento do temporizador que tenta verificar a conexão com a internet e avançar se bem-sucedido.
        private async void TentativaLigacao(object sender, EventArgs e)
        {
            if (await VerificaLigacaoInternet())
            {
                retryTimer.Stop();
                view.Invoke(new Action(() => {
                    view.PedeViewJogador();
                }));
            }
            else
            {
                view.Invoke(new Action(() => {
                    view.MostraMensagem("Não foi possível ligar à base de dados. Por favor aguarde enquanto tentamos estabelecer ligação....");
                }));
            }
        }
        // Método que verifica a ligação à internet e começa o jogo se possível.
        public async void VerificaLigacaoeComecaJogo()
        {
            if (await VerificaLigacaoInternet())
            {
                retryTimer.Stop();
                view.PedeViewJogador();
            }
            else
            {
                view.MostraMensagem("Não foi possível ligar à base de dados. Por favor aguarde enquanto tentamos estabelecer ligação....");
                retryTimer.Start();
            }
        }

        // Método assíncrono para verificar a ligação à internet.
        private async Task<bool> VerificaLigacaoInternet()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var response = await client.GetAsync("http://clients3.google.com/generate_204");
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }


        public void ProcessaJogador(string playerName)
        {
            var statement = new TinCan.Statement
            {
                actor = new TinCan.Agent { name = playerName, mbox = "mailto:" + playerName + "@example.com" },
                verb = new TinCan.Verb
                {
                    id = new Uri("http://adlnet.gov/expapi/verbs/interacted"), // Verb adequado para a ação
                },
                target = new TinCan.Activity
                {
                    id = "http://example.com/quizgame",
                }
            };

            TinCan.LRSResponses.StatementLRSResponse lrsResponse = lrs.SaveStatement(statement);
            if (lrsResponse.success)
            {
                MessageBox.Show("Olá " + playerName + ", bem-vindo ao quiz d3v-n3rds!");
            }
            else
            {
                MessageBox.Show("Error saving player name: " + lrsResponse.errMsg);
            }
        }




        // Método assíncrono para obter categorias de perguntas de uma API externa.
        public async Task<string> GetCategoriesAsync()
        {
            string url = "https://tryvia.ptr.red/api_category.php";
            try
            {
                using (var client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(url);
                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        throw new HttpRequestException($"Falha ao obter resposta da API. StatusCode: {response.StatusCode}");
                    }
                }
            }
            catch (HttpRequestException ex) when (ex.InnerException is System.Net.Sockets.SocketException)
            {
                MessageBox.Show("Não foi possível ligar à base de dados. Por favor, verifique a sua ligação de internet e tente novamente.", "Erro de ligação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocorreu um erro ao tentar buscar categorias: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        // Método assíncrono para obter um token de uma API, utilizado para garantir que perguntas não se repitam.

        public async Task<string> RequestTokenAsync()
        {
            string url = "https://tryvia.ptr.red/api_token.php?command=request";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    var tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(await response.Content.ReadAsStringAsync());
                    return tokenResponse.Token;  // Supondo que a resposta seja um objeto JSON com um campo 'Token'
                }
            }
            return null;
        }
        // Método assíncrono para obter perguntas de uma categoria específica, com parâmetros adicionais como tipo e dificuldade.

        public async Task<string> GetQuestionsAsync(int quantidadeDePerguntas, int? categoria, string tipo, string dificuldade, string token)
        {
            string url = $"https://tryvia.ptr.red/api.php?amount={quantidadeDePerguntas}&token={token}";

            if (categoria.HasValue)
                url += $"&category={categoria.Value}";
            if (!string.IsNullOrEmpty(tipo))
                url += $"&type={tipo}";
            if (!string.IsNullOrEmpty(dificuldade))
                url += $"&difficulty={dificuldade}";

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string content = await response.Content.ReadAsStringAsync();
                    return content; // Pode ser necessário deserializar o JSON
                }
            }
            return null;
        }


        // Método para carregar categorias e mostrar botões correspondentes na interface do usuário.

        public async void CarregaCategorias()
        {
            string categoriesJson = await GetCategoriesAsync(); // Este método deve fazer uma chamada HTTP para obter o JSON
            if (!string.IsNullOrEmpty(categoriesJson))
            {
                var response = JsonConvert.DeserializeObject<TriviaCategoryResponse>(categoriesJson);
                if (response != null && response.Categories != null && response.Categories.Count > 0)
                    view.MostraBotaoCategoria(response.Categories); // Este método deve criar botões na view para cada categoria
                else
                    MessageBox.Show("Nenhuma categoria foi carregada.");
            }
            else
            {
                MessageBox.Show("Erro ao carregar categorias.");
            }
        }

        public async void FetchQuestionsForCategory(int categoryId)
        {
            string token = await RequestTokenAsync();
            if (string.IsNullOrEmpty(token))
            {
                MessageBox.Show("Não foi possível obter o token.");
                return;
            }

            int quantidadeDePerguntas = 5;  // Defina a quantidade de perguntas desejadas
            string questionsJson = await GetQuestionsAsync(quantidadeDePerguntas, categoryId, "multiple", "medium", token);

            if (!string.IsNullOrEmpty(questionsJson))
            {
                var questions = JsonConvert.DeserializeObject<QuestionsResponse>(questionsJson);
                if (questions != null && questions.Questions.Count > 0)
                {
                    view.MostraPerguntas(questions);
                }
                else
                {
                    MessageBox.Show("Nenhuma pergunta foi carregada.");
                }
            }
            else
            {
                MessageBox.Show("Erro ao carregar perguntas.");
            }
        }


        public void LigarJogo()
        {
            view.BotaoClicado();
        }

        public void SetTheme(string theme)
        {
            model.SetTheme(theme);
            view.UpdateThemeLabel(theme);
        }
    }


}



