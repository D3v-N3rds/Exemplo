﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// Model.cs
namespace Quiz_Game_in_Windows_Form
{
    public class Model
    {
        public string CurrentTheme { get; set; }

        public Model()
        {
        }

        
        public void SetTheme(string theme)
        {
            CurrentTheme = theme;
        }
    }
}

