// Program.cs
using System;
using System.Windows.Forms;

namespace Quiz_Game_in_Windows_Form
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Model model = new Model();
            View view = new View();
            Controller controller = new Controller(view, model);
            Application.Run(view);
        }
    }
}
