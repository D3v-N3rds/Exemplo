using System;
using System.Net;
using System.Windows.Forms;
using TinCan.LRSResponses;
using System.Net.Http;
using System.Threading.Tasks;


namespace Quiz_Game_in_Windows_Form
{
    public partial class View : Form
    {
        private Controller controller;
        private Label themeLabel;  // Label para mostrar o tema selecionado
        private System.Windows.Forms.Timer retryTimer;

        // M�todo para mostrar mensagens de erro numa janela de di�logo.
        public void MostraMensagem(string message)
        {
            MessageBox.Show(message, "Erro de Conex�o", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        
        // Construtor da classe View que inicializa componentes da interface do utilizador.

        public View()
        {
            InicializaComponente();
        }

        // M�todo para associar um controlador � view

        public void Controlador(Controller c)
        {
            controller = c;
        }


        // Evento para come�ar o Jogo
        private void LigarJogo(object sender, EventArgs e)
        {
            controller.VerificaLigacaoeComecaJogo();


        }
        // M�todo para solicitar o nome do jogador atrav�s de uma caixa de di�logo.

        public void PedeViewJogador()
        {
            string playerName = Microsoft.VisualBasic.Interaction.InputBox("Qual � o seu nome?", "Nome do Jogador", "Digite seu nome aqui", 500, 300);
            if (!string.IsNullOrEmpty(playerName))
            {
                controller.ProcessaJogador(playerName);
                BotaoClicado();
            }
        }

        // M�todo para limpar a interface e exibir op��es para escolha de tema.

        public void BotaoClicado()
        {
            this.Controls.Clear();  // Limpa todos os controlos existentes na form

            Label lblChooseTheme = new Label();
            lblChooseTheme.Text = "Escolha o Tema";
            lblChooseTheme.AutoSize = true;
            lblChooseTheme.Location = new Point((this.ClientSize.Width - lblChooseTheme.Width) / 2, 20);
            lblChooseTheme.Size = new Size(200, 40);
            this.Controls.Add(lblChooseTheme);

            controller.CarregaCategorias();  // Carrega os temas
        }

        // M�todo para exibir bot�es para cada categoria filtrada de perguntas.

        public void MostraBotaoCategoria(List<Category> categories)
        {
            var filteredCategories = categories.Where(c => c.Name.Contains("Entretenimento: Filmes") ||
                                                           c.Name.Contains("Entretenimento: M�sicas") ||
                                                           c.Name == "Geografia" ||
                                                           c.Name == "Hist�ria" ||
                                                           c.Name == "Conhecimentos gerais").ToList();

            int buttonWidth = 200;  // Largura definida para os bot�es
            int buttonHeight = 30;  // Altura definida para os bot�es
            int spacing = 25;       // Espa�amento entre os bot�es
            int posY = 50;         // Posi��o inicial Y para os bot�es

            foreach (var category in filteredCategories)
            {
                Button btnCategoria = new Button();
                btnCategoria.Text = category.Name;
                btnCategoria.Size = new Size(buttonWidth, buttonHeight);
                btnCategoria.Tag = category.Id;  


                // Calcular a posi��o X centralizada
                int posX = (this.ClientSize.Width - btnCategoria.Width) / 2;

                btnCategoria.Location = new Point(posX, posY);
                btnCategoria.Click += BotaoSelecionaCategoria;
                this.Controls.Add(btnCategoria);

                posY += buttonHeight + spacing; // Incrementa a posi��o Y para o pr�ximo bot�o
            }
        }



        // Manipulador de eventos do bot�o de categoria
        private void BotaoSelecionaCategoria(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                int categoryId = (int)btn.Tag;
                controller.FetchQuestionsForCategory(categoryId); // Chama o m�todo no Controller
            }
        }

        // M�todo para exibir perguntas e respostas na interface do utilizador.

        public void MostraPerguntas(QuestionsResponse questionsResponse)
        {
            this.Controls.Clear(); // Limpa a tela para nova exibi��o de perguntas

            int posY = 20;

            foreach (var question in questionsResponse.Questions)
            {
                Label questionLabel = new Label();
                questionLabel.Text = question.Text;
                questionLabel.AutoSize = true;
                questionLabel.Location = new Point(50, posY);
                this.Controls.Add(questionLabel);

                posY += 30;

                foreach (var answer in question.IncorrectAnswers.Concat(new[] { question.CorrectAnswer }).OrderBy(a => Guid.NewGuid()))
                {
                    RadioButton answerButton = new RadioButton();
                    answerButton.Text = answer;
                    answerButton.Location = new Point(60, posY);
                    answerButton.AutoSize = true;
                    this.Controls.Add(answerButton);

                    posY += 24;
                }

                posY += 20;
            }
        }

        public void UpdateThemeLabel(string theme)
        {
            themeLabel.Text = "Tema Selecionado: " + theme;
        }

        private void InitializeComponent()
        {

        }
    }
}



