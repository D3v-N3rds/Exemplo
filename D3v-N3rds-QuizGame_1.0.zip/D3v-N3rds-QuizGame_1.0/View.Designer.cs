﻿namespace Quiz_Game_in_Windows_Form
{
    partial class View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InicializaComponente()
        {
            pictureBox1 = new PictureBox();
            label1 = new Label();
            btnStartGame = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.nerdsquiz;
            pictureBox1.Location = new Point(219, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(308, 264);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(219, 289);
            label1.Name = "label1";
            label1.Size = new Size(308, 29);
            label1.TabIndex = 1;
            label1.Text = "Selecione uma opção";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnStartGame
            // 
            btnStartGame.Location = new Point(283, 331);
            btnStartGame.Name = "btnStartGame";
            btnStartGame.Size = new Size(154, 43);
            btnStartGame.TabIndex = 2;
            btnStartGame.Tag = "1";
            btnStartGame.Text = "Iniciar Jogo";
            btnStartGame.UseVisualStyleBackColor = true;
            btnStartGame.Click += LigarJogo;
            // 
            // View
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnStartGame);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "View";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);

            // Inicializa componentes adicionais
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Text = "Quiz Game";

            this.themeLabel = new System.Windows.Forms.Label();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.difficultyLabel = new System.Windows.Forms.Label();

            // Define propriedades dos componentes adicionais
            this.themeLabel.AutoSize = true;
            this.themeLabel.Location = new System.Drawing.Point(10, 10);
            this.Controls.Add(this.themeLabel);

            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Location = new System.Drawing.Point(this.ClientSize.Width - 100, 10);
            this.Controls.Add(this.scoreLabel);

            this.difficultyLabel.AutoSize = true;
            this.difficultyLabel.Location = new System.Drawing.Point((this.ClientSize.Width / 2) - 50, 10);
            this.Controls.Add(this.difficultyLabel);
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Button btnStartGame;
    }
}