﻿using TinCan;
using TinCan.LRSResponses;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Quiz_Game_in_Windows_Form
{
    public class Controller : IController
    {
        private Model model;
        private View view;
        private RemoteLRS lrs;
        private System.Windows.Forms.Timer retryTimer = new System.Windows.Forms.Timer();
        private int playerScore;
        private string playerName;

        public Controller(View v, Model m)
        {
            this.view = v;
            this.model = m;
            this.view.Controlador(this);
            retryTimer.Interval = 3000;
            retryTimer.Tick += TentativaLigacao;

            // Inicialize o LRS com suas credenciais SCORM Cloud
            this.lrs = new RemoteLRS(
                "https://cloud.scorm.com/lrs/6B1O2UCFT6/",
                "d3v.n3rd2024@gmail.com", // Substitua pelo seu nome de usuário
                "D3v_N3rds2024"  // Substitua pela sua senha
            );
        }

        // Tentativa de ligação à internet
        private async void TentativaLigacao(object sender, EventArgs e)
        {
            if (await VerificaLigacaoInternet())
            {
                retryTimer.Stop();
                view.Invoke(new Action(() => view.PedeViewJogador()));
            }
            else
            {
                view.Invoke(new Action(() => view.MostraMensagem("Não foi possível ligar à base de dados. Por favor aguarde enquanto tentamos estabelecer ligação....")));
            }
        }

        // Verifica a ligação à internet e começa o jogo
        public async void VerificaLigacaoeComecaJogo()
        {
            if (await VerificaLigacaoInternet())
            {
                retryTimer.Stop();
                view.PedeViewJogador();
            }
            else
            {
                view.MostraMensagem("Não foi possível ligar à base de dados. Por favor aguarde enquanto tentamos estabelecer ligação....");
                retryTimer.Start();
            }
        }

        // Verifica se há ligação à internet
        private async Task<bool> VerificaLigacaoInternet()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var response = await client.GetAsync("http://clients3.google.com/generate_204");
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }

        // Processa os dados do jogador
        public void ProcessaJogador(string playerName)
        {
            this.playerName = playerName; // Armazena o nome do jogador
            var statement = new TinCan.Statement
            {
                actor = new TinCan.Agent { name = playerName, mbox = "mailto:" + playerName.Replace(" ", "") + "@example.com" },
                verb = new TinCan.Verb { id = new Uri("http://adlnet.gov/expapi/verbs/interacted") },
                target = new TinCan.Activity { id = "http://example.com/quizgame" }
            };

            TinCan.LRSResponses.StatementLRSResponse lrsResponse = lrs.SaveStatement(statement);
            if (lrsResponse.success)
            {
                MessageBox.Show("Olá " + playerName + ", bem-vindo ao quiz d3v-n3rds!");
                CarregaCategorias(); // Carregar as categorias ao processar o jogador
            }
            else
            {
                MessageBox.Show("Error saving player name: " + lrsResponse.errMsg);
            }
        }

        // Calcula o nível de experiência do jogador
        private int CalcularNivelDeExperiencia(string playerName)
        {
            var query = new StatementsQuery();
            query.agent = new Agent { mbox = "mailto:" + playerName + "@example.com" };

            var lrsResponse = lrs.QueryStatements(query);
            if (lrsResponse.success)
            {
                var statements = lrsResponse.content.statements;
                return statements.Count % 3 + 1; // Exemplo fictício de cálculo
            }
            return 1; // Nível padrão se não houver interações
        }

        // Obtém a dificuldade com base no nível de experiência
        private string ObterDificuldadeParaNivel(int nivelDeExperiencia)
        {
            switch (nivelDeExperiencia)
            {
                case 1: return "easy";
                case 2: return "medium";
                case 3: return "hard";
                default: return "medium";
            }
        }

        // Obtém a dificuldade com base no score
        public string ObterDificuldadeParaScore(int score)
        {
            if (score < 50)
            {
                return "easy";
            }
            else if (score < 100)
            {
                return "medium";
            }
            else
            {
                return "hard";
            }
        }

        // Obtém categorias de perguntas
        public async Task<string> GetCategoriesAsync()
        {
            return await model.GetCategoriesAsync();
        }

        // Solicita um token
        public async Task<string> RequestTokenAsync()
        {
            return await model.RequestTokenAsync();
        }

        // Obtém perguntas da API
        public async Task<string> GetQuestionsAsync(int quantidadeDePerguntas, int? categoria, string tipo, string dificuldade, string token)
        {
            return await model.GetQuestionsAsync(quantidadeDePerguntas, categoria, tipo, dificuldade, token);
        }

        // Carrega categorias de perguntas
        public async void CarregaCategorias()
        {
            string categoriesJson = await GetCategoriesAsync();
            if (!string.IsNullOrEmpty(categoriesJson))
            {
                try
                {
                    Console.WriteLine("Resposta da API de categorias: " + categoriesJson); // Adiciona log da resposta JSON completa
                    var response = JsonConvert.DeserializeObject<TriviaCategoryResponse>(categoriesJson);
                    if (response != null && response.TriviaCategories != null && response.TriviaCategories.Count > 0)
                    {
                        // Filtrar as categorias desejadas
                        var categoriasDesejadas = new List<string> { "Conhecimentos gerais", "Entretenimento: Filmes", "História", "Geografia", "Arte" };
                        var categoriasFiltradas = response.TriviaCategories.Where(c => categoriasDesejadas.Contains(c.Name)).ToList();
                        Console.WriteLine("Categorias filtradas: " + string.Join(", ", categoriasFiltradas.Select(c => c.Name))); // Adiciona log das categorias filtradas
                        view.MostraBotaoCategoria(categoriasFiltradas);
                    }
                    else
                    {
                        MessageBox.Show("Nenhuma categoria foi carregada. Verifique a resposta da API.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao desserializar resposta da API: {ex.Message}");
                    Console.WriteLine("Erro ao desserializar resposta da API: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Erro ao carregar categorias.");
            }
        }

        // Busca perguntas para uma categoria específica
        public async void FetchQuestionsForCategory(int categoryId, string playerName)
        {
            string token = await RequestTokenAsync();
            if (string.IsNullOrEmpty(token))
            {
                MessageBox.Show("Não foi possível obter o token.");
                return;
            }

            int quantidadeDePerguntas = 5;
            string dificuldade = ObterDificuldadeParaScore(playerScore);

            Console.WriteLine($"Carregando perguntas para categoria {categoryId} com dificuldade {dificuldade} usando token {token}");

            string questionsJson = await GetQuestionsAsync(quantidadeDePerguntas, categoryId, "multiple", dificuldade, token);

            if (!string.IsNullOrEmpty(questionsJson))
            {
                try
                {
                    Console.WriteLine("Resposta da API de perguntas: " + questionsJson); // Adiciona log da resposta JSON completa
                    var questions = JsonConvert.DeserializeObject<QuestionsResponse>(questionsJson);
                    if (questions != null && questions.Questions != null && questions.Questions.Count > 0)
                    {
                        view.UpdateDifficultyLabel(dificuldade);
                        Console.WriteLine($"Perguntas carregadas com dificuldade {dificuldade}:");
                        foreach (var question in questions.Questions)
                        {
                            Console.WriteLine($"- {question.QuestionText} (Dificuldade: {dificuldade})");
                        }
                        view.MostraPerguntas(questions.Questions, playerName); // Passar o nome do jogador aqui
                    }
                    else
                    {
                        MessageBox.Show("Nenhuma pergunta foi carregada.");
                        Console.WriteLine("Resposta desserializada está nula ou não contém perguntas.");
                        Console.WriteLine("Resposta da API: " + questionsJson);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao desserializar resposta da API: {ex.Message}");
                    Console.WriteLine("Erro ao desserializar resposta da API: " + ex.Message);
                    Console.WriteLine("Resposta da API: " + questionsJson);
                }
            }
            else
            {
                MessageBox.Show("Erro ao carregar perguntas.");
                Console.WriteLine("Erro: A resposta da API está vazia ou nula.");
            }
        }

        // Envia dados de experiência para o LRS
        public async Task SendExperienceData(string playerName, int score, string difficulty)
        {
            var statement = new TinCan.Statement
            {
                actor = new TinCan.Agent { name = playerName, mbox = "mailto:" + playerName.Replace(" ", "") + "@example.com" },
                verb = new TinCan.Verb { id = new Uri("http://adlnet.gov/expapi/verbs/answered") },
                target = new TinCan.Activity { id = "http://example.com/quizgame" },
                result = new TinCan.Result { score = new TinCan.Score { raw = score }, response = difficulty, success = score > 50 }
            };

            TinCan.LRSResponses.StatementLRSResponse lrsResponse = await Task.Run(() => lrs.SaveStatement(statement));
            if (!lrsResponse.success)
            {
                MessageBox.Show("Error saving statement: " + lrsResponse.errMsg);
            }
            else
            {
                playerScore += score; // Atualiza o score do jogador
                Console.WriteLine($"Score atualizado para {playerScore}. Próxima dificuldade: {ObterDificuldadeParaScore(playerScore)}");
                AtualizarScoreLabel(playerScore); // Atualiza a label de score na view
            }
        }

        // Atualiza a label de score na view
        public void AtualizarScoreLabel(int score)
        {
            view.UpdateScoreLabel(score);
        }

        // Inicia o jogo
        public void LigarJogo()
        {
            view.BotaoClicado();
        }

        // Define o tema
        public void SetTheme(string theme)
        {
            model.SetTheme(theme);
            view.UpdateThemeLabel(theme);
        }

        // Mostra o botão para jogar novamente
        public void MostraBotaoJogarNovamente()
        {
            view.MostraBotaoJogarNovamente(playerName, playerScore);
        }
    }
}
