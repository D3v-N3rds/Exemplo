﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

public class XapiHelper
{
    private readonly string endpoint;
    private readonly string username;
    private readonly string password;

    public XapiHelper(string endpoint, string username, string password)
    {
        this.endpoint = endpoint;
        this.username = username;
        this.password = password;
    }

    // Envia uma declaração de experiência do jogador para o LRS
    public async Task SendStatementAsync(string playerName, int score, string difficulty)
    {
        var statement = new
        {
            actor = new
            {
                name = playerName,
                mbox = $"mailto:{playerName.Replace(" ", "")}@example.com"
            },
            verb = new
            {
                id = "http://adlnet.gov/expapi/verbs/answered",
                display = new { en = "answered" }
            },
            @object = new
            {
                id = "http://example.com/activities/quiz",
                definition = new
                {
                    name = new { en = "Quiz" },
                    description = new { en = "A quiz activity" }
                },
                objectType = "Activity"
            },
            result = new
            {
                score = new { raw = score },
                success = score > 50,
                response = difficulty
            }
        };

        string jsonStatement = JsonConvert.SerializeObject(statement);
        var content = new StringContent(jsonStatement, Encoding.UTF8, "application/json");

        using (var client = new HttpClient())
        {
            var byteArray = Encoding.ASCII.GetBytes($"{username}:{password}");
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

            HttpResponseMessage response = await client.PostAsync(endpoint, content);
            response.EnsureSuccessStatusCode();
        }
    }

    // Obtém o nível de experiência do jogador
    public async Task<int> GetPlayerExperienceLevelAsync(string playerName)
    {
        using (var client = new HttpClient())
        {
            var byteArray = Encoding.ASCII.GetBytes($"{username}:{password}");
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

            string queryUrl = $"{endpoint}/statements?agent={{{JsonConvert.SerializeObject(new { mbox = $"mailto:{playerName.Replace(" ", "")}@example.com" })}}}";
            HttpResponseMessage response = await client.GetAsync(queryUrl);
            response.EnsureSuccessStatusCode();

            string content = await response.Content.ReadAsStringAsync();
            var statements = JsonConvert.DeserializeObject<XapiStatementsResponse>(content);

            int experienceLevel = CalculateExperienceLevel(statements);
            return experienceLevel;
        }
    }

    // Calcula o nível de experiência com base nas declarações
    private int CalculateExperienceLevel(XapiStatementsResponse statements)
    {
        // Implementar lógica de cálculo do nível de experiência com base nas declarações
        // Aqui está um exemplo simples que retorna um nível de experiência fictício com base na contagem de declarações
        int totalStatements = statements.Statements.Count;
        if (totalStatements < 10)
        {
            return 1; // Nível iniciante
        }
        else if (totalStatements < 20)
        {
            return 2; // Nível intermediário
        }
        else
        {
            return 3; // Nível avançado
        }
    }
}

// Classes auxiliares para deserialização das respostas da API xAPI
public class XapiStatementsResponse
{
    public List<XapiStatement> Statements { get; set; }
}

public class XapiStatement
{
    public string Id { get; set; }
    public XapiActor Actor { get; set; }
    public XapiVerb Verb { get; set; }
    public XapiObject Object { get; set; }
    public XapiResult Result { get; set; }
    public DateTime Timestamp { get; set; }
}

public class XapiActor
{
    public string Name { get; set; }
    public string Mbox { get; set; }
}

public class XapiVerb
{
    public string Id { get; set; }
    public XapiLanguageMap Display { get; set; }
}

public class XapiObject
{
    public string Id { get; set; }
    public XapiDefinition Definition { get; set; }
    public string ObjectType { get; set; }
}

public class XapiResult
{
    public XapiScore Score { get; set; }
    public bool Success { get; set; }
    public string Response { get; set; }
}

public class XapiScore
{
    public float Raw { get; set; }
}

public class XapiDefinition
{
    public XapiLanguageMap Name { get; set; }
    public XapiLanguageMap Description { get; set; }
}

public class XapiLanguageMap
{
    public string En { get; set; }
}
