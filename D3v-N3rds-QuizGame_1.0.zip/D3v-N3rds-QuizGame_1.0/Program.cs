using System;
using System.Windows.Forms;

namespace Quiz_Game_in_Windows_Form
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Model model = new Model();
            View view = new View(null); // Inicialize sem o controlador
            Controller controller = new Controller(view, model); // Inicialize o controlador com view e model

            view.Controlador(controller); // Configure a view para usar o controlador

            Application.Run(view); // Inicia a aplicação com a view principal
        }
    }
}