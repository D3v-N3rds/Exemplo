﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Quiz_Game_in_Windows_Form
{
    public class Model
    {
        public string CurrentTheme { get; set; }

        public Model()
        {
            CurrentTheme = null;
        }

        // Define o tema atual
        public void SetTheme(string theme)
        {
            CurrentTheme = theme;
        }

        // Obtém categorias de perguntas da API
        public async Task<string> GetCategoriesAsync()
        {
            string url = "https://tryvia.ptr.red/api_category.php";
            try
            {
                using (var client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(url);
                    if (response.IsSuccessStatusCode)
                    {
                        string content = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Resposta da API de categorias: " + content);
                        return content;
                    }
                    else
                    {
                        throw new HttpRequestException($"Falha ao obter resposta da API. StatusCode: {response.StatusCode}");
                    }
                }
            }
            catch (HttpRequestException ex) when (ex.InnerException is System.Net.Sockets.SocketException)
            {
                Console.WriteLine("Não foi possível ligar à base de dados. Por favor, verifique a sua ligação de internet e tente novamente.");
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro ao tentar buscar categorias: {ex.Message}");
                return null;
            }
        }

        // Solicita um token da API
        public async Task<string> RequestTokenAsync()
        {
            string url = "https://tryvia.ptr.red/api_token.php?command=request";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    var tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(await response.Content.ReadAsStringAsync());
                    return tokenResponse.Token;
                }
            }
            return null;
        }

        // Obtém perguntas da API
        public async Task<string> GetQuestionsAsync(int quantidadeDePerguntas, int? categoria, string tipo, string dificuldade, string token)
        {
            string url = $"https://tryvia.ptr.red/api.php?amount={quantidadeDePerguntas}&token={token}";
            if (categoria.HasValue)
                url += $"&category={categoria.Value}";
            if (!string.IsNullOrEmpty(tipo))
                url += $"&type={tipo}";
            if (!string.IsNullOrEmpty(dificuldade))
                url += $"&difficulty={dificuldade}";

            Console.WriteLine($"Solicitando perguntas da URL: {url}");

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string content = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Resposta da API de perguntas: " + content);
                    return content;
                }
                else
                {
                    Console.WriteLine($"Erro ao solicitar perguntas. StatusCode: {response.StatusCode}");
                }
            }
            return null;
        }
    }
}
