﻿using Newtonsoft.Json;

namespace Quiz_Game_in_Windows_Form
{
    // Classe para deserialização da resposta do token
    public class TokenResponse
    {
        public string Token { get; set; }
    }

    // Classe para deserialização da resposta das categorias de trivia
    public class TriviaCategoryResponse
    {
        [JsonProperty("trivia_categories")] // Use a anotação para mapear o nome do JSON
        public List<Category> TriviaCategories { get; set; }

        public class Category
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }
    }

    // Classe para deserialização da resposta das perguntas
    public class QuestionsResponse
    {
        [JsonProperty("results")] // Ajuste para corresponder ao JSON
        public List<Question> Questions { get; set; } = new List<Question>();

        public class Question
        {
            public string Category { get; set; }
            public string Type { get; set; }
            public string Difficulty { get; set; }
            [JsonProperty("question")]
            public string QuestionText { get; set; }
            [JsonProperty("incorrect_answers")]
            public List<string> IncorrectAnswers { get; set; }
            [JsonProperty("correct_answer")]
            public string CorrectAnswer { get; set; }
        }
    }
}