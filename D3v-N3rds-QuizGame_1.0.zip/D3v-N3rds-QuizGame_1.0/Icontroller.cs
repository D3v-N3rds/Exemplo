namespace Quiz_Game_in_Windows_Form
{
    public interface IController
    {
        void VerificaLigacaoeComecaJogo();
        void ProcessaJogador(string playerName);
        Task<string> GetCategoriesAsync();
        Task<string> RequestTokenAsync();
        Task<string> GetQuestionsAsync(int quantidadeDePerguntas, int? categoria, string tipo, string dificuldade, string token);
        Task SendExperienceData(string playerName, int score, string difficulty);
        string ObterDificuldadeParaScore(int score);
        void CarregaCategorias();
        void FetchQuestionsForCategory(int categoryId, string playerName);
        void AtualizarScoreLabel(int score);
        void LigarJogo();
        void SetTheme(string theme);
        void MostraBotaoJogarNovamente();
    }
}
