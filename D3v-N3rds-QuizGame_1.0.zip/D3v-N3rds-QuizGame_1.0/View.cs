using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Quiz_Game_in_Windows_Form
{
    public partial class View : Form
    {
        private IController controller;
        private Label themeLabel;
        private Label scoreLabel; 
        private Label difficultyLabel; 
        private System.Windows.Forms.Timer retryTimer;
        private List<QuestionWithAnswers> questionsWithAnswers;
        private string playerName; 

        public View(IController controller)
        {
            this.controller = controller;
            InicializaComponente();
            // Definir o tamanho fixo da janela
            this.Size = new Size(800, 700);
            this.MaximumSize = this.Size;
            this.MinimumSize = this.Size;
        }

        // Configura o controlador
        public void Controlador(IController c)
        {
            controller = c;
        }

        // Mostra uma mensagem de erro
        public void MostraMensagem(string message)
        {
            MessageBox.Show(message, "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Handler para iniciar o jogo
        private void LigarJogo(object sender, EventArgs e)
        {
            controller.VerificaLigacaoeComecaJogo();
        }

        // Pede o nome do jogador
        public void PedeViewJogador()
        {
            playerName = Microsoft.VisualBasic.Interaction.InputBox("Qual é o seu nome?", "Nome do Jogador", "Digite seu nome aqui", 500, 300);
            if (!string.IsNullOrEmpty(playerName))
            {
                controller.ProcessaJogador(playerName);
            }
        }

        // Limpa a interface e exibe o botão de categorias
        public void BotaoClicado()
        {
            this.Controls.Clear();
            Label lblChooseTheme = new Label
            {
                Text = "Escolha o Tema",
                AutoSize = true,
                Location = new Point((this.ClientSize.Width - 200) / 2, 10) // Centralizar horizontalmente
            };
            this.Controls.Add(lblChooseTheme);

            // Carregar categorias dinamicamente da API
            controller.CarregaCategorias();
        }

        // Exibe os botões de categorias
        public void MostraBotaoCategoria(List<TriviaCategoryResponse.Category> categories)
        {
            Console.WriteLine("Chamando MostraBotaoCategoria"); // Adiciona log para verificar se o método é chamado
            this.Controls.Clear();
            Label lblChooseTheme = new Label
            {
                Text = "Escolha o Tema",
                AutoSize = true,
                Location = new Point((this.ClientSize.Width - 200) / 2, 10) // Centralizar horizontalmente
            };
            this.Controls.Add(lblChooseTheme);

            int yOffset = 50; // Distância inicial do topo
            foreach (var category in categories)
            {
                Console.WriteLine("Adicionando categoria: " + category.Name); // Adiciona log para verificar as categorias adicionadas
                Button btnCategoria = new Button
                {
                    Text = category.Name,
                    Tag = category.Id,
                    Size = new Size(200, 40),
                    Location = new Point((this.ClientSize.Width - 200) / 2, yOffset) // Centralizar horizontalmente
                };
                btnCategoria.Click += (sender, e) =>
                {
                    if (!string.IsNullOrEmpty(playerName))
                    {
                        controller.FetchQuestionsForCategory((int)btnCategoria.Tag, playerName);
                    }
                    else
                    {
                        MessageBox.Show("Por favor, insira seu nome primeiro.");
                    }
                };
                this.Controls.Add(btnCategoria);
                yOffset += 50; // Incrementa a posição vertical para o próximo botão
            }
        }

        // Exibe as perguntas
        public void MostraPerguntas(List<QuestionsResponse.Question> questions, string playerName)
        {
            this.Controls.Clear();
            questionsWithAnswers = new List<QuestionWithAnswers>();

            TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
            {
                ColumnCount = 1,
                RowCount = questions.Count + 1, // Uma linha adicional para o botão de submissão
                Dock = DockStyle.Fill,
                AutoSize = true
            };
            this.Controls.Add(tableLayoutPanel);

            this.difficultyLabel = new Label
            {
                Text = $"Dificuldade: {questions.First().Difficulty}",
                AutoSize = true,
                Dock = DockStyle.Top
            };
            tableLayoutPanel.Controls.Add(this.difficultyLabel);

            foreach (var question in questions)
            {
                var questionWithAnswers = new QuestionWithAnswers { Question = question };

                GroupBox groupBox = new GroupBox
                {
                    Text = question.QuestionText,
                    AutoSize = true,
                    Dock = DockStyle.Top
                };
                tableLayoutPanel.Controls.Add(groupBox);

                List<string> allAnswers = new List<string>(question.IncorrectAnswers)
                {
                    question.CorrectAnswer
                };
                allAnswers = allAnswers.OrderBy(a => Guid.NewGuid()).ToList(); // Embaralhar respostas

                foreach (var answer in allAnswers)
                {
                    RadioButton rbtnAnswer = new RadioButton
                    {
                        Text = answer,
                        AutoSize = true,
                        Dock = DockStyle.Top
                    };
                    groupBox.Controls.Add(rbtnAnswer);

                    // Associar RadioButton com a pergunta
                    questionWithAnswers.Answers.Add(rbtnAnswer);
                }

                questionsWithAnswers.Add(questionWithAnswers);
            }

            // Adicionar botão de submissão
            Button btnSubmit = new Button
            {
                Text = "Submeter Respostas",
                Dock = DockStyle.Bottom,
                Height = 40
            };
            btnSubmit.Click += async (sender, e) => await SubmeterRespostas(playerName);
            tableLayoutPanel.Controls.Add(btnSubmit);
        }

        // Submete as respostas do jogador
        private async Task SubmeterRespostas(string playerName)
        {
            int correctCount = 0;
            int totalCount = questionsWithAnswers.Count;

            foreach (var q in questionsWithAnswers)
            {
                var selectedAnswer = q.Answers.FirstOrDefault(r => r.Checked)?.Text;
                if (selectedAnswer == q.Question.CorrectAnswer)
                {
                    correctCount++;
                }
            }

            MessageBox.Show($"Você acertou {correctCount} de {totalCount} perguntas.");

            int score = correctCount * 20; // Calcule o score baseado nas respostas corretas
            string dificuldade = controller.ObterDificuldadeParaScore(score); // Obtenha a dificuldade com base no score
            // Enviar dados de experiência para a SCORM Cloud
            await controller.SendExperienceData(playerName, score, dificuldade); // Passe a dificuldade

            // Atualizar o score na label
            controller.AtualizarScoreLabel(score); // Atualize a label com o novo score

            // Permitir que o jogador jogue novamente, passando o score total
            controller.MostraBotaoJogarNovamente();
        }

        // Exibe o botão para jogar novamente
        public void MostraBotaoJogarNovamente(string playerName, int totalScore)
        {
            this.Controls.Clear();

            Label lblMessage = new Label
            {
                Text = $"Gostaria de jogar novamente? \nSeu score total é: {totalScore}",
                AutoSize = true,
                Location = new Point((this.ClientSize.Width - 200) / 2, 10)
            };
            this.Controls.Add(lblMessage);

            Button btnJogarNovamente = new Button
            {
                Text = "Jogar Novamente",
                Size = new Size(200, 40),
                Location = new Point((this.ClientSize.Width - 200) / 2, 50)
            };
            btnJogarNovamente.Click += (sender, e) => controller.CarregaCategorias();
            this.Controls.Add(btnJogarNovamente);
        }

        // Atualiza a label do tema
        public void UpdateThemeLabel(string theme)
        {
            if (themeLabel == null)
            {
                themeLabel = new Label
                {
                    AutoSize = true,
                    Location = new Point(10, 10)
                };
                this.Controls.Add(themeLabel);
            }
            themeLabel.Text = $"Tema Atual: {theme}";
        }

        // Atualiza a label do score
        public void UpdateScoreLabel(int score)
        {
            if (scoreLabel == null)
            {
                scoreLabel = new Label
                {
                    AutoSize = true,
                    Location = new Point(this.ClientSize.Width - 100, 10)
                };
                this.Controls.Add(scoreLabel);
            }
            scoreLabel.Text = $"Score: {score}";
        }

        // Atualiza a label da dificuldade
        public void UpdateDifficultyLabel(string difficulty)
        {
            if (difficultyLabel == null)
            {
                difficultyLabel = new Label
                {
                    AutoSize = true,
                    Location = new Point((this.ClientSize.Width / 2) - 50, 10) // Centralizada no topo
                };
                this.Controls.Add(difficultyLabel);
            }
            difficultyLabel.Text = $"Dificuldade: {difficulty}";
        }
    }

    public class QuestionWithAnswers
    {
        public QuestionsResponse.Question Question { get; set; }
        public List<RadioButton> Answers { get; set; } = new List<RadioButton>();
    }
}
